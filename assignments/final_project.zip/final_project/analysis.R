library(here)
library(arrow)
library(tidyverse)
library(igraph)
library(tidygraph)
library(ggraph)
library(gridExtra)
library(plotly)

### LOAD DATA
data_path <- here('assignments','final_project',"672_project_data")
results <- read_parquet(here(data_path, 'results.parquet'))
outp <- read_parquet(here(data_path, 'output.parquet'))


### VISUALIZE
summary <- results %>% 
  group_by(timestep, desc, thresh) %>%
  summarize(adoption = mean(value)) %>%
  ungroup() %>%
  mutate(thresh = as.factor(thresh))
 

(ggplot(summary %>% filter(desc == 'random_start' & timestep <= 25), 
       aes(x=timestep, y=adoption, color=thresh)) +
  geom_line(size=0.2) +
  theme_minimal()) %>% ggplotly()


(ggplot(summary %>% filter(thresh == 0.25  & timestep <= 25 & desc %in% c('male_start', 'female_start')), 
       aes(x=timestep, y=adoption, color=desc)) +
  geom_line(size=0.2) +
  theme_minimal())  %>% ggplotly()
